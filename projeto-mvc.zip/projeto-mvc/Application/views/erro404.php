<div class="container">
  <div class="row">
    <div class="col-12 text-center" style="margin-top:200px">
      <img src="./assets/img/erro.png">
    </div>
  </div>
</div>
